﻿$computername=$env:COMPUTERNAME
$data=Get-EventLog System -EntryType Error -Newest 100 -ComputerName $computername|group -Property Source -NoElement
#HTML
$title="system log analysis"
$footer ="<h5> report run $(Get-Date)</h5>"
$data|sort -Property count,name -Descending|select count,name|
ConvertTo-Html -Title $title -PreContent "<h1>$computername</h1>" -PostContent $footer -CssUri style.css|
Out-File C:\temp\jeetendra\eventlog\event.html

